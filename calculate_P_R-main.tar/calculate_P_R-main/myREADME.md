## train

Step1. rewrite sample.py.
```shell
(640, 512)

[dects.append(d) for d in detections if (d[1] == c and d[2] > 0.6)]

metricsPerClass = GetPascalVOCMetrics(boundingboxes, IOUThreshold=0.3,)
```

Step2. run sample.py.
